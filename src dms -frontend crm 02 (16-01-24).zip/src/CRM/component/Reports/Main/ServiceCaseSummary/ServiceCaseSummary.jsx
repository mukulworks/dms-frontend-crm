import React from 'react'

const ServiceCaseSummary = () => {
    return (
        <div>
            ServiceCaseSummary
        </div>
    )
}

export default ServiceCaseSummary

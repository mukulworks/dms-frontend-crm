import React from 'react'

const FollowType = () => {
    return(
        <div>
            Follow Type
            <select>
                <option>Follow Type</option>
                <option>Follow Category</option>
                <option>Bucket</option>
                <option>Month Year</option>
                <option>Caller</option>
            </select>  
        </div>
    )
}

export default FollowType;
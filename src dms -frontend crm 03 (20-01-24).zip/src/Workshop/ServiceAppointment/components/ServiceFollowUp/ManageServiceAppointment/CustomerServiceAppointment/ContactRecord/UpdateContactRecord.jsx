import React from 'react'

const UpdateContactRecord = () => {
    return (
        <div className="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">...</div>
    )
}

export default UpdateContactRecord


import serviceAppointment from './serviceAppointmentReducer';

const rootWorkshopReducer = {
    serviceAppointment
};

export default rootWorkshopReducer;
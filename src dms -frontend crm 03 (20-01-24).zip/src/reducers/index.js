
import dialer from './dialerReducer';
import login from './loginReducer';
import user from './userReducer';

const rootReducer = {
  dialer,login,user
};

export default rootReducer;
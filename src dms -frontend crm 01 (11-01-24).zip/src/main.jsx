window.global = window.global || {};
import("./bootstrap");
